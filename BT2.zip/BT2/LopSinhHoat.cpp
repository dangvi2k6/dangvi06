#include "LopSinhHoat.h"
LopSinhHoat::LopSinhHoat(char *ten, SinhVien *ds, Lecture gv, int siSo)
{
    tenLop = ten;
    danhSachSV = ds;
    gvCN = gv;
    siSoSV = siSo;
}