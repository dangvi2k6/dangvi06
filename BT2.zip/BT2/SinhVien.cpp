#include "SinhVien.h"

SinhVien::SinhVien(): Person(), mssv(nullptr), lop(LopSinhHoat()), diemTB(0.0) {}
SinhVien::SinhVien(char *n, int a, char *ad, bool g, char *ms, LopSinhHoat l, double dtb)
{
    mssv = ms;
    lop = l;
    diemTB = dtb;
    if(ms[0]=='\0' && strlen(ms)!=10) {
        cout<<"MSSV khong hop le"<<endl;
        mssv = nullptr;
    } 
    if(dtb<0.0||dtb>4.0){
        cout<<"Diem trung binh khong hop le. Dat mac dinh bang 0.0"<<endl;
    }
    
}
SinhVien::~SinhVien()
{
}

istream& operator>>(istream &i, SinhVien &obj)
{
    i>>(Person&)obj;
    cout<<"Nhap MSSV: ";
    i>>obj.mssv;
    while(obj.mssv[0]=='\0'&& strlen(obj.mssv)!=10) {
        cout<<"MSSV khong duoc de trong. Vui long nhap lai: ";
        i>>obj.mssv;
    }
    cout<<"Nhap lop: ";
    i>>obj.lop;
    cout<<"Nhap diem trung binh: ";
    i>>obj.diemTB;

}
ostream& operator<<(ostream &o, const SinhVien &obj)
{
    o << (Person&)obj << ", MSSV: " << (obj.mssv ? obj.mssv : "N/A") 
      << ", Diem TB: " << obj.diemTB 
      << ", Lop: " << obj.lop;
    return o;
}