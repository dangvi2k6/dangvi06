#include "Person.h"
Person::Person() : name(nullptr), age(0), address(nullptr), gender(true) {}
Person::Person(char *n, int a, char *ad, bool g)
{
    name = n;
    age = a;
    address =ad;
    gender=g;
}
Person::~Person()
{
    delete[] name;
    delete[] address;
}
istream& operator>>(istream& i, Person& p) {
    cout<<"Nhap ten: ";
    i>>p.name;
    cout<<"Nhap tuoi: ";
    i>>p.age;
    cout<<"Nhap dia chi: ";
    i>>p.address;
    cout<<"Nhap gioi tinh (1-Nam, 0-Nu): ";
    i>>p.gender;
    return i;
}
ostream& operator<<(ostream& o, const Person& p) {
    o << "Ten: " << (p.name ? p.name : "N/A") 
    << ", Tuoi: " << p.age 
    << ", Dia chi: " << (p.address ? p.address : "N/A")
    << ", Gioi tinh: " << (p.gender ? "Nam" : "Nu");
    return o;
}
