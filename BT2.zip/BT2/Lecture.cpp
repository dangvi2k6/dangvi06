#include "Lecture.h"
Lecture::Lecture():Person(), maGV(nullptr), capBac(nullptr) {}
Lecture::Lecture(char *n, int a, char *ad, bool g, char *mg, char *cb):Person(n, a, ad, g)
{
    maGV = mg;
    capBac = cb;
}
Lecture::~Lecture()
{
}